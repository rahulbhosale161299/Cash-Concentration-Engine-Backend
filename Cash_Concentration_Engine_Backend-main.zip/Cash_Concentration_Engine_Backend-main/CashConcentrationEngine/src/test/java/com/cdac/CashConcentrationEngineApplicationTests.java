//package com.cdac;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.cdac.entity.Company;
//
//@SpringBootTest
//class CashConcentrationEngineApplicationTests {
//	
//	
//	
//
//	@Test
//	void contextLoads() {
//	}
//	
//	void findAllCompany() {
////		Company company = new Company("104","Adani Power","2023-05-06 5:08:22","May",4000000,
////				500000,2500000,6450000,"Jalgaon","Maharashtra");
////		
//		
//		
//		
//	
//	}
//
//}
